# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request, 'users_app/index.html')

def register(request):
	return render(request, 'users_app/register.html')

def login(request):
	return render(request, 'users_app/login.html')

def new(request):
	return render(request, 'users_app/newUser.html')